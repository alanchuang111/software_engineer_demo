use std::fs::File;
use std::io::Read;
fn main() {

// Rust 的開啟檔案操作回傳的是 Result 列舉，而非可能為空的值
let file = File::open("Null.txt");
let mut content = String::new();

//file.read_to_string(&mut content);
//println!("[讀取成功] 檔案內容如下：{}", content);

// 強制要求錯誤處理
match file {
        Ok(mut file) => {
            
            // 讀取操作本身也可能會失敗所以也要求錯誤處理
            match file.read_to_string(&mut content) {
                Ok(_) => {
                    println!("[讀取成功] 檔案內容如下：{}", content);
                }
                Err(e) => {
                    println!("[錯誤] 讀取內容失敗: {}", e);
                }
            }
        }
        Err(e) => {
            println!("[錯誤] 無法開啟檔案（檔案可能不存在）：{}", e);
            
        }
    }
}